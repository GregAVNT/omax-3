<?php get_header(); ?>
<section id="page">
    <div class="container">
        <div id="content" class="site-content" role="main">
        	<div class='container omax'>
        		<div class='row'>
        			<div class='col-xs-12'>
	        			<h3 class='section_head'>2 Capsules. One Big Boost.</h3>
        			</div>
        		</div>
        		<div class='row'>
        			<div class='col-sm-4 col-xs-12'>
        		
	        			<h4 class=''>Superior Quality</h4>
	        			<p>Here's some lorem-ipsum for ya. Pretty great, right?</p>
        			</div>
        			<div class='col-sm-4 col-xs-12'>
	        			<h4 class=''>Unparalleled Potency</h4>
	        			<p>Here's some lorem-ipsum for ya. Pretty great, right?</p>
        			</div>
        			<div class='col-sm-4 col-xs-12'>
	        			<h4 class=''>Advanced Formula</h4>
	        			<p>omax3's patented 4:1 EPA to DHA ratio has proven benefits beyond those of any other omega-3 supplement.</p>
	        			<a class='btn md-btn green' href="#">Learn More</a>
        			</div>
        		</div>
			</div>
       </div><!--/#content-->
    </div>
</section><!--/#page-->
<?php get_footer();